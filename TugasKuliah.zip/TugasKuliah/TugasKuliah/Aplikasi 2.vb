﻿Imports System.Console

Friend Module Program2
    Public Sub Secondary()
        WriteLine("-------=== Ini adalah Aplikasi 2 mulai dari poin A hingga G ===-------")
        HitungFkeC()
        HitungFkeR()
        HitungRkeF()
        HitungCkeF()
        HitungYardkeCm()
        HitungFeetkeCm()
        SatuanJam()
    End Sub

    Public Sub HitungFkeC()
        Dim a As Integer
        Dim hasil As Integer
        WriteLine("A. Aplikasi Penghitung Konversi Fahrenheit ke Celcius")
        WriteLine("Masukkan Nilai Suhu Fahrenheit")
        a = ReadLine()
        hasil = 5 / 9 * (a - 32)

        WriteLine("Hasilnya adalah " & hasil & " C")
    End Sub
    Public Sub HitungFkeR()
        Dim a As Integer
        Dim hasil As Integer
        WriteLine("B. Aplikasi Penghitung Konversi Fahrenheit ke Reamur")
        WriteLine("Masukkan Nilai Suhu Fahrenheit")
        a = ReadLine()
        hasil = 4 / 9 * (a - 32)

        WriteLine("Hasilnya adalah " & hasil & " R")

    End Sub
    Public Sub HitungRkeF()
        Dim a As Integer
        Dim hasil As Integer
        WriteLine("C. Aplikasi Penghitung Konversi Reamur ke Fahrenheit")
        WriteLine("Masukkan Nilai Suhu Reamur")
        a = ReadLine()
        hasil = (9 / 4 * a) + 32

        WriteLine("Hasilnya adalah " & hasil & " F")
    End Sub
    Public Sub HitungCkeF()
        Dim a As Integer
        Dim hasil As Integer
        WriteLine("D. Aplikasi Penghitung Konversi Celcius ke Fahrenheit")
        WriteLine("Masukkan Nilai Suhu Celcius")
        a = ReadLine()
        hasil = (a * 9 / 5) + 32

        WriteLine("Hasilnya adalah " & hasil & " F")
    End Sub
    Public Sub HitungYardkeCm()
        Dim a As Integer
        Dim hasil As Integer
        WriteLine("E. Aplikasi Penghitung Konversi Yard ke Cm")
        WriteLine("Masukkan Nilai dalam Satuan Yard")
        a = ReadLine()

        hasil = a * 91.44
        WriteLine("Hasilnya adalah " & hasil & " Cm")
    End Sub
    Public Sub HitungFeetkeCm()
        Dim a As Integer
        Dim hasil As Integer
        WriteLine("F. Aplikasi Penghitung Konversi Feet ke Cm")
        WriteLine("Masukkan Nilai dalam Satuan Feet")
        a = ReadLine()

        hasil = a * 30.48
        WriteLine("Hasilnya adalah " & hasil & " Cm")
    End Sub
    Public Sub SatuanJam()
        Dim a As Integer
        Dim hasil As Integer

        WriteLine("G. Aplikasi Konversi Jam ke Menit")
        WriteLine("Masukkan Nilai Dalam Satuan Jam")
        a = ReadLine()
        hasil = a * 60

        WriteLine("Hasilnya adalah " & hasil & " menit")
    End Sub
End Module