﻿Imports System.Console
Module Aplikasi5
    Sub Main()
        aplikasi5a()
        aplikasi5b()
        aplikasi5c()
        aplikasi5d()
    End Sub
    Sub aplikasi5a()
        'Aplikasi Cek Kelulusan
        '1. Tentukan variabel
        Dim nilai As Byte
        Dim hasil As String

        '2. Masukkan Nilai
        WriteLine("---=== Aplikasi Cek Kelulusan ===---")
        WriteLine("Masukkan Nilai")
        nilai = ReadLine()

        '3. Output hasil
        If nilai > 60 Then
            hasil = "LULUS"
        Else
            hasil = "TIDAK LULUS"
        End If
        WriteLine("Anda dinyatakan " & hasil)
    End Sub
    Sub aplikasi5b()
        'Aplikasi Cek Tingkat Usia
        '1. Tentukan variabel 
        Dim usia As Byte
        Dim hasil As String

        '2. Masukkan nilai
        WriteLine("---=== Aplikasi Cek Tingkat Usia ===---")
        WriteLine("Masukkan Usia Anda & Ketahui Tingkat Anda")
        usia = ReadLine()
        '3. Output
        If usia > 60 Then
            hasil = "LANSIA"
        End If
        If usia >= 35 And usia <= 59 Then
            hasil = "DEWASA"
        End If
        If usia >= 18 And usia <= 34 Then
            hasil = "PEMUDA"
        End If
        If usia >= 15 And usia <= 17 Then
            hasil = "REMAJA"
        End If

        WriteLine("Tingkat Usia Anda Adalah " & hasil)
    End Sub
    Sub aplikasi5c()
        'Aplikasi1 Cek Predikat Nilai
        '1. Tentukan Variabel
        Dim nilai As Byte
        Dim hasil As String
        '2. Masukkan Nilai
        WriteLine("---=== Aplikasi Cek Predikat Nilai ===---")
        WriteLine("Masukkan Nilai Anda & Dapatkan Predikat Anda")
        nilai = ReadLine()
        '3. Output
        If nilai > 80 Then
            hasil = "BAIK SEKALI"
        End If
        If nilai >= 65 Then
            hasil = "BAIK"
        End If
        If nilai >= 55 Then
            hasil = "CUKUP"
        End If
        If nilai >= 40 Then
            hasil = "KURANG"
        End If
        If nilai < 40 Then
            hasil = "KURANG SEKALI"
        End If
        WriteLine("Predikat Nilai Anda Adalah " & hasil)
    End Sub
    Sub aplikasi5d()
        'Aplikasi1 Cek Predikat Nilai
        '1. Tentukan Variabel
        Dim nilai As Byte
        Dim hasil As String
        '2. Masukkan Nilai
        WriteLine("---=== Aplikasi Cek Predikat Nilai ===---")
        WriteLine("Masukkan Nilai Anda & Dapatkan Predikat Anda")
        nilai = ReadLine()
        '3. Output
        If nilai >= 91 And nilai < 100 Then
            hasil = "A"
        End If
        If nilai >= 81 And nilai < 91 Then
            hasil = "B"
        End If
        If nilai >= 71 And nilai < 81 Then
            hasil = "C"
        End If
        If nilai < 71 Then
            hasil = "D"
        End If
        WriteLine("Predikat Nilai Anda Adalah " & hasil)
    End Sub
End Module
