﻿Imports System.Console
Module Aplikasi6
    Sub Main()
        aplikasi6a()
        aplikasi6b()
        aplikasi6c()
        aplikasi6d()
        aplikasi6e()
    End Sub
    Sub aplikasi6a()
        Dim strUlang As String
        strUlang = "Y"
        Do While UCase(strUlang) = "Y"
            '1. deklarasi variabel harga per biji dan jumlah beli
            Dim Harga As Single
            Dim JmlBeli As Integer
            Dim Total As Single
            'beri nilai awal variabel intJmlBeli = harga 1 printer
            Harga = 660000
            JmlBeli = 0
            '2. Input/baca jumlah beli
            WriteLine("Aplikasi hitung harga jumlah printer yang dibeli")
            WriteLine("Jumlah printer yang dibeli =")
            JmlBeli = ReadLine()
            '3. hitung total
            Total = JmlBeli * Harga
            '4. tampilkan
            WriteLine("Total Bayar = " & JmlBeli & " * " & "Rp " &
            Format(Harga, "0,00#") & " = Rp " & Format(Total, "0,00#"))
            WriteLine("Hitung Lagi? = Y/T")
            strUlang = ReadLine()
            Clear()
        Loop
    End Sub
    Sub aplikasi6b()
        Dim strUlang As String
        strUlang = "Y"
        Do While UCase(strUlang) = "Y"
            '1. deklarasi variabel harga per biji dan jumlah beli
            Dim Harga As Single
            Dim JmlBeli As Integer
            Dim TotalAkhir As Single
            Dim TotalAwal As Single
            Dim Diskon As Single

            'beri nilai awal variabel intJmlBeli = harga 1 printer
            Harga = 660000
            JmlBeli = 0

            '2. Input/baca jumlah beli
            WriteLine("Aplikasi Penghitung Pembelian Printer T20")
            WriteLine("
Syarat Diskon : 
1. Pembelian Diatas Rp.1.500.000 Mendapat Diskon 15%
2. Dibawah Rp. 1.500.000 Tidak Mendapat Diskon")
            WriteLine("Jumlah printer yang dibeli =")
            JmlBeli = ReadLine()

            '3. hitung total dan diskon
            TotalAwal = JmlBeli * Harga

            '4. hitung total diskon
            If TotalAwal > 1500000 Then
                Diskon = TotalAwal * 0.15
            ElseIf TotalAwal < 1500000 Then
                Diskon = 0
            End If
            TotalAkhir = TotalAwal - Diskon

            '5. tampilkan hasil akhir
            WriteLine("=====================================================================")
            WriteLine("Total Bayar = " & JmlBeli & " * " & "Rp " & Format(Harga, "0,00#") & " - " & Format(Diskon, "0,00#") & " = Rp " & Format(TotalAkhir, "0,00#"))
            WriteLine("=====================================================================")
            WriteLine("Hitung Lagi? = Y/T")
            strUlang = ReadLine()
            Clear()
        Loop
    End Sub
    Sub aplikasi6c()
        Dim strUlang As String
        strUlang = "Y"

        Do While UCase(strUlang) = "Y"
            '1. Tentukan variabel nilai
            Dim waktu As Single
            Dim upah As Single
            '2. Tuliskan ketentuan
            WriteLine("Aplikasi Penghitung Upah Bekerja Berdasarkan Waktu Bekerja")
            WriteLine("Upah = Rp. 2.500/jam
===================================================")
            WriteLine("Masukkan Lama Waktu Anda Bekerja")
            waktu = ReadLine()
            WriteLine("===================================================")
            '3. Penghitungan
            upah = waktu * 2500
            '4. Hasil akhir
            WriteLine("Total Upah Bekerja Adalah " & "Rp." & Format(upah, "0,00#"))
            WriteLine("===================================================")
            WriteLine("Hitung Lagi? = Y/T")
            strUlang = ReadLine()
            Clear()
        Loop
    End Sub
    Sub aplikasi6d()
        Dim strUlang As String
        strUlang = "Y"
        Do While UCase(strUlang) = "Y"
            '1. Tentukan variabel nilai
            Dim waktu As Single
            Dim upahawal As Single
            Dim pajak As Single
            Dim upahakhir As Single
            '2. Tuliskan ketentuan
            WriteLine("Aplikasi Penghitung Upah Bekerja Berdasarkan Waktu Bekerja")
            WriteLine("Upah = Rp. 2.500/jam
Pajak = 15%
===================================================")
            WriteLine("Masukkan Lama Waktu Anda Bekerja")
            waktu = ReadLine()
            WriteLine("===================================================")
            '3. Penghitungan
            upahawal = waktu * 2500
            pajak = upahawal * 0.15
            upahakhir = upahawal - pajak
            '4. Hasil akhir
            WriteLine("Total Upah Bekerja Adalah " & "Rp." & Format(upahawal, "0,00#") & "-" & Format(pajak, "0,00#") & "=" & "Rp." & Format(upahakhir, "0,00#"))
            WriteLine("===================================================")
            WriteLine("Hitung Lagi? = Y/T")
            strUlang = ReadLine()
            Clear()
        Loop
    End Sub
    Sub aplikasi6e()
        Dim strUlang As String
        strUlang = "Y"
        Do While UCase(strUlang) = "Y"
            '1. Tentukan variabel 
            Dim pilihan As String
            Dim biaya As Single
            '2. Masukkan pilihan
            WriteLine("Aplikasi Penghitung Biaya Ongkir Berdasarkan Jarak")
            WriteLine("Berikut adalah pilihan kota beserta biaya perkm :
1. Surabaya = 169 km @ Rp.2.500/km
2. Bandung = 452 km @ Rp.4.000/km")
            WriteLine("Silakan pilih kota tujuan Anda")
            pilihan = ReadLine()
            '3. Penghitung Ongkir
            If pilihan = "1" Then
                biaya = 169 * 2500
            ElseIf pilihan = "2" Then
                biaya = 452 & 4000
            End If
            '4. Hasil output
            WriteLine("Total biaya ongkirnya adalah " & "Rp." & Format(biaya, "0,00#"))
            WriteLine("Hitung Lagi? = Y/T")
            strUlang = ReadLine()
            Clear()
        Loop
    End Sub
End Module
