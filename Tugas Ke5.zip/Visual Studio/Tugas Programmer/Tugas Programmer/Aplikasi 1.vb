Imports System.Console

Module Aplikasi1
    Sub Main()
        WriteLine("--------=== ini adalah Aplikasi 1 mulai dari poin A hingga L ===---------")
        Tulisan()
        HitungLuasPersegiPanjang()
        HitungKelilingPersegiPanjang()
        HitungLuasSegitiga()
        HitungKelilingSegitiga()
        HitungLuasBalok()
        HitungVolumeBalok()
        HitungLuasLingkaran()
        HitungLuasTabung()
        HitungLuasTrapesium()
        BilanganGanjilGenap()
        BilanganPositifNegatif()

    End Sub

    Sub Tulisan()
        WriteLine("A. Hello world! ini adalah output tulisan!")

    End Sub

    Sub HitungLuasPersegiPanjang()
        Dim P As Integer
        Dim L As Integer
        Dim Luas As Integer

        WriteLine("B. Ini adalah aplikasi penghitung luas persegi panjang")
        WriteLine("Silakan Input Nilai P =")
        P = ReadLine()
        WriteLine("Silakan Input Nilai L =")
        L = ReadLine()

        Luas = P * L

        WriteLine("Luas dari Persegi panjang adalah = " & Luas)

    End Sub

    Sub HitungKelilingPersegiPanjang()
        Dim P As Integer
        Dim L As Integer
        Dim Keliling As Integer

        WriteLine("C. Berikut ini adalah aplikasi penghitung Keliling Persegi Panjang")
        WriteLine("Silakan input nilai P")
        P = ReadLine()
        WriteLine("Silakan input nilai L")
        L = ReadLine()

        Keliling = 2 * (P + L)

        WriteLine("Keliling Persegi Panjang adalah = " & Keliling)

    End Sub

    Sub HitungLuasSegitiga()
        Dim a As Single
        Dim t As Single
        Dim hasil As Single

        WriteLine("D. Aplikasi Penghitung Luas Segitiga")
        WriteLine("Masukan nilai alas")
        a = ReadLine()
        WriteLine("Masukan nilai tinggi")
        t = ReadLine()

        hasil = a * t / 2

        WriteLine("Hasil luas segitiga adalah = " & hasil)
    End Sub

    Sub BilanganGanjilGenap()
        Dim n As Single
        Dim hasil As String

        WriteLine("K. Berikut ini adalah aplikasi pengecek nilai ganjil genap")
        WriteLine("Silakan input nilai")
        n = ReadLine()

        If n Mod 2 = 0 Then
            hasil = n & " Adalah Bilangan Genap"
        Else
            hasil = n & " Adalah Bilangan Ganjil"
        End If

        WriteLine(hasil)
    End Sub

    Sub HitungKelilingSegitiga()
        Dim a As Single
        Dim b As Single
        Dim c As Single
        Dim hasil As Single

        WriteLine("E. Aplikasi Penghitung Keliling Segitiga")
        WriteLine("Masukan nilai a")
        a = ReadLine()
        WriteLine("Masukan nilai b")
        b = ReadLine()
        WriteLine("Masukan nilai c")
        c = ReadLine()

        hasil = a + b + c

        WriteLine("Hasilnya adalah = " & hasil)

    End Sub

    Sub HitungLuasBalok()
        Dim p As Single
        Dim l As Single
        Dim t As Single
        Dim hasil As Single

        WriteLine("F. Aplikasi Penghitung Luas Balok")
        WriteLine("Masukan nilai p atau Panjang")
        p = ReadLine()
        WriteLine("Masukan nilai l atau Lebar")
        l = ReadLine()
        WriteLine("Masukan nilai t atau Tinggi")
        t = ReadLine()

        hasil = 2 * (p * l + p * t + l * t)

        WriteLine("Hasilnya adalah = " & hasil)
    End Sub

    Sub HitungVolumeBalok()
        Dim p As Single
        Dim l As Single
        Dim t As Single
        Dim hasil As Single

        WriteLine("G. Aplikasi Penghitung Luas Balok")
        WriteLine("Masukan nilai p atau Panjang")
        p = ReadLine()
        WriteLine("Masukan nilai l atau Lebar")
        l = ReadLine()
        WriteLine("Masukan nilai t atau Tinggi")
        t = ReadLine()

        hasil = p * l * t
        WriteLine("Hasilnya adalah = " & hasil)
    End Sub

    Sub HitungLuasLingkaran()
        Dim r As String
        Dim phi As String
        Dim hasil As String
        phi = 3.14

        WriteLine("H. Aplikasi Penghitung Luas Lingkaran")
        WriteLine("Masukan nilai r atau jari - jari")
        r = ReadLine()

        hasil = phi * r ^ 2

        WriteLine("Hasilnya adalah " & hasil)

    End Sub

    Sub HitungLuasTabung()
        Dim r As String
        Dim t As String
        Dim phi As String
        Dim hasil As String

        phi = 3.14
        WriteLine("I. Aplikasi Penghitung Luas Selimut Tabung")
        WriteLine("Masukan nilai r atau jari - jari")
        r = ReadLine()
        WriteLine("Masukan nilai tinggi")
        t = ReadLine()

        hasil = 2 * phi * r * t
        WriteLine("Hasilnya adalah " & hasil)

    End Sub

    Sub HitungLuasTrapesium()
        Dim a As Integer
        Dim b As Integer
        Dim t As Integer
        Dim hasil As Integer

        WriteLine("J. Aplikasi Penghitung Luas Trapesium")
        WriteLine("Masukan nilai sisi a")
        a = ReadLine()
        WriteLine("Masukan nilai sisi b")
        b = ReadLine()
        WriteLine("Masukan nilai t")
        t = ReadLine()

        hasil = (a + b) * t / 2
        WriteLine("Hasilnya adalah " & hasil)

    End Sub

    Sub BilanganPositifNegatif()
        Dim n As Single
        Dim hasil As String

        WriteLine("L. Berikut ini adalah aplikasi pengecek nilai genap atau positif")
        WriteLine("Silakan input nilai")
        n = ReadLine()

        If n > 0 Then
            hasil = n & " Adalah Bilangan Positif"
        Else
            hasil = n & " Adalah Bilangan Negatif"
        End If

        WriteLine(hasil)
    End Sub
End Module
